const chartData = [
    { id: 'bar1', value: 70 },
    { id: 'bar2', value: 50 },
    { id: 'bar3', value: 90 },
    { id: 'bar4', value: 30 }
];
const chartData2 = [
    { id: 'bar5', value: 10 },
    { id: 'bar6', value: 50 },
    { id: 'bar7', value: 50 },
    { id: 'bar8', value: 30 }
];

// Функция для создания диаграммы
function createChart(data) {
    data.forEach(item => {
        const barElement = document.getElementById(item.id);
        if (barElement) {
            // Устанавливаем высоту столбца в процентах
            barElement.style.height = `${item.value}%`;
          
        }
    });
}

const chartData3 = [
    { id: 'bar9', value: 60 },
    { id: 'bar10', value: 80 }
];

// Функция для создания диаграммы
function createChart2(data) {
    data.forEach(item => {
        const barElement = document.getElementById(item.id);
        if (barElement) {
            // Устанавливаем ширину столбца в процентах
            barElement.style.width = `${item.value}%`;
            // Добавляем текстовое значение ширины
            barElement.textContent = `${item.value}%`;
        }
    });
}

createChart(chartData);
createChart(chartData2);
createChart2(chartData3);